"""
VastData VectorStore - LangChain integration for HTTP-based vector stores.

This package provides a LangChain VectorStore implementation that interfaces
with HTTP-based vector store APIs, specifically designed for VastData's
vector store service.
"""

from .vectorstore import VastDataVectorStore

__version__ = "0.1.0"
__author__ = "VastData"
__email__ = "support@vastdata.com"

__all__ = [
    "VastDataVectorStore",
]
