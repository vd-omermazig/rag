"""LangChain VectorStore implementation for HTTP-based vector store."""

import logging
from typing import Any, Dict, List, Optional

import requests
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VST
from langchain_core.vectorstores.base import VectorStore

logger = logging.getLogger(__name__)


class VastDataVectorStore(VectorStore):
    """VectorStore implementation that interfaces with HTTP-based vector store API."""

    def __init__(
        self,
        base_url: str,
        collection_name: str,
        auth_token: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: int = 30,
    ):
        """Initialize the VastData VectorStore.

        Args:
            base_url: Base URL of the HTTP vector store API
            collection_name: Name of the collection to use
            auth_token: Optional authentication token
            headers: Optional additional headers
            timeout: Request timeout in seconds
        """
        self.base_url = base_url.rstrip("/")
        self.collection_name = collection_name
        self.timeout = timeout

        self.headers = headers or {}
        if auth_token:
            self.headers["Authorization"] = f"Bearer {auth_token}"
        self.headers["Content-Type"] = "application/json"

    def _make_request(
        self, method: str, endpoint: str, data: Optional[Dict] = None
    ) -> requests.Response:
        """Make HTTP request to the vector store API."""
        url = f"{self.base_url}{endpoint}"

        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self.headers,
                json=data,
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            logger.error(f"HTTP request failed: {e}")
            raise

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        **kwargs: Any,
    ) -> List[Document]:
        """Return docs most similar to query"""
        request_data = {
            "collection_name": self.collection_name,
            "prompt": query,
            "number_of_docs": k,
            "with_rerank": False,
        }

        response = self._make_request("POST", "/api/v1/retrieve", request_data)
        chunks = response.json()

        docs = []
        for chunk in chunks:
            doc = Document(
                page_content=chunk["content"],
                metadata={
                    "id": chunk["id"],
                    "doc_path": chunk["doc_path"],
                    "page_number": chunk.get("page_number"),
                    "start_index": chunk.get("start_index"),
                },
            )
            docs.append(doc)

        return docs

    @classmethod
    def from_texts(
        cls: type[VST],
        texts: list[str],
        embedding: Embeddings,
        metadatas: Optional[list[dict]] = None,
        *,
        ids: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> VST:
        raise NotImplementedError(
            "Text addition not supported by this HTTP API. You should use external ingestion"
        )
